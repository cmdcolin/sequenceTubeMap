export interface Site {
    left: number;
    right: number;
    inserted: number;
}
export declare function siteKey({ left, right, inserted }: Site): string;
export declare function clusterLeaders(tally: Map<string, {
    site: Site;
    haplotypes: number;
}>, offsets: number[], tolerance: number): Map<string, Site>;
