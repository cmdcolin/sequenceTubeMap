import type { FoldResult, InputNode, InputTrack } from './types.ts';
export declare function foldProblems<N extends InputNode, T extends InputTrack>(nodes: N[], tracks: T[], result: FoldResult<N, T>): string[];
