export interface Anchor {
    ref: number;
    reversed: boolean;
    step: number;
}
export interface Run {
    reversed: boolean;
    anchors: Anchor[];
}
export declare function runsOf(anchors: Anchor[]): Run[];
export declare function runBounds({ anchors }: Run): {
    start: number;
    end: number;
};
export declare function chain(anchors: Anchor[], offsets: number[], threshold: number): Run[];
