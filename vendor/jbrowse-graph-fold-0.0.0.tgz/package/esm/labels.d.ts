import type { Branch, FoldedTrackFields } from './types.ts';
export declare function bpLabel(bp: number): string;
export declare function branchLabel(branch: Branch, haplotypes: number): string;
export declare function trackLabel(freq: number, names: string[]): string;
export declare function variationLabel({ freq, variation }: FoldedTrackFields): string;
