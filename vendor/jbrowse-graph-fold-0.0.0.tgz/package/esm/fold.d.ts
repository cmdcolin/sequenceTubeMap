import type { FoldOptions, FoldResult, InputNode, InputTrack } from './types.ts';
export declare function foldGraph(nodes: InputNode[], tracks: InputTrack[], options?: FoldOptions): FoldResult;
