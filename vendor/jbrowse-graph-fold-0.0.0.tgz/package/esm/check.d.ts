import type { FoldResult, InputNode, InputTrack } from './types.ts';
export declare function foldProblems(nodes: InputNode[], tracks: InputTrack[], result: FoldResult): string[];
