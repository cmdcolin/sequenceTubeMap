import type { FoldOptions, Folded, InputNode, InputTrack, Unfolded } from './types.ts';
export declare function foldGraph<N extends InputNode, T extends InputTrack>(nodes: N[], tracks: T[], options?: FoldOptions): Folded<T> | Unfolded<N, T>;
